import math

def polar2rect(r, theta):
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return (x, y)

r = 2
theta = math.pi / 4  # 45 degrees in radians

result = polar2rect(r, theta)
print(result)