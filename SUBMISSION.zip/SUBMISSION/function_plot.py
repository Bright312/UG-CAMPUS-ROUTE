import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-3, 3, 101)
y = np.exp(-x) * np.sin(3*x)

plt.plot(x, y)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Plot of y = e^(-x) * sin(3x)')
plt.grid(True)
plt.show()