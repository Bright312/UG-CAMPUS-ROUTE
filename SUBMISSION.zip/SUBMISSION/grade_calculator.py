def get_grade(Marks, Class_Attendance, Total_Lectures):
    Score = Marks + 10 * (Class_Attendance / Total_Lectures)
    
    if Score >= 80:
        Remark = "Distinction"
    elif Score >= 50:
        Remark = "Pass"
    else:
        Remark = "Fail"
    
    grade_dict = {
        "Score": Score,
        "Remark": Remark
    }
    
    return grade_dict
Marks = 70
Class_Attendance = 40
Total_Lectures = 50

result = get_grade(Marks, Class_Attendance, Total_Lectures)
print(result)