def vect_dist(a, b):
    distance =((a[0] - b[0])  2 + (a[1] - b[1])  2 + (a[2] - b[2])  2)  0.5
    return distance

a = (0, 4, 6)
b = (0, 2, 6)

result = vect_dist(a, b)
print(result)