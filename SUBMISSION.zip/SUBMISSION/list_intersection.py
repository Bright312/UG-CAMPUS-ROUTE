def list_intersect(A, B):
    intersection = [value for value in A if value in B]
    return intersection

A = [1, 2, 3, 4, 5]
B = [4, 5, 6, 7, 8]

result = list_intersect(A, B)
print(result)