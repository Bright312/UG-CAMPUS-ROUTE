import math
def circ_area(radius):
    return math.pi * radius**2
radius = 1
area = circ_area(radius)
print ("The area of the circle with radius", radius,"is:",area)