def line_intersect(line1, line2):
    m1, c1 = line1
    m2, c2 = line2
    
    if m1 - m2 == 0:
        return "No intersection (parallel lines)"
    
    x = (c2 - c1) / (m1 - m2)
    y = m1 * x + c1
    
    return (x, y)

line1 = (2, 3)
line2 = (-1, 4)

result = line_intersect(line1, line2)
print(result)