def isAP(sequence):
    if len(sequence) < 3:
        return False
    
    d = sequence[1] - sequence[0]
    
    for i in range(2, len(sequence)):
        if sequence[i] - sequence[i-1] != d:
          return False
    
    return True
sequence = [1, 3, 5, 6, 9, 11, 13]
result = isAP(sequence)
print("Does the sequence form an arithmetic sequence?", result)